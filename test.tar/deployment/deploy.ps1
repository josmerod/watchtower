# Deploy Watchtower to Unraid (Remote Build)
# Usage: ./deployment/deploy.ps1

$ServerIP = "192.168.31.126"
$RemoteUser = "root"
$RemoteDir = "/tmp/watchtower_deploy"
$TarFile = "watchtower_src.tar.gz"

Write-Host "1. Creating source archive..." -ForegroundColor Cyan
# Exclude heavy/unnecessary folders
# Windows tar (bsdtar) syntax
tar --exclude ".git" --exclude ".venv" --exclude ".venv_main" --exclude ".venv_test" --exclude "__pycache__" --exclude "data" --exclude "*.tar.gz" -czf $TarFile .

if ($LASTEXITCODE -ne 0) { Write-Error "Failed to create archive"; exit 1 }

Write-Host "2. Uploading archive to $ServerIP..." -ForegroundColor Cyan
Write-Host "   (You may be asked for password: Josele1305!)" -ForegroundColor Gray
scp $TarFile "${RemoteUser}@${ServerIP}:/tmp/${TarFile}"

if ($LASTEXITCODE -ne 0) { Write-Error "SCP failed"; exit 1 }

Write-Host "3. Building and Deploying on Remote Server..." -ForegroundColor Cyan
$RemoteScript = @"
set -e
echo '   -> Extracting...'
rm -rf $RemoteDir
mkdir -p $RemoteDir
tar -xzf /tmp/$TarFile -C $RemoteDir

echo '   -> Building Docker Image...'
cd $RemoteDir
docker build -t watchtower -f deployment/Dockerfile .

echo '   -> Restarting Container...'
docker stop watchtower || true
docker rm watchtower || true

docker run -d \
  --name watchtower \
  --restart unless-stopped \
  -p 7777:7777 \
  -v /mnt/user/appdata/watchtower/data:/app/data \
  -v /mnt/user/appdata/watchtower/logs:/app/logs \
  -e TZ=Europe/Madrid \
  watchtower

echo '   -> Cleanup...'
rm -rf $RemoteDir /tmp/$TarFile
echo '   -> Done!'
"@

ssh -t "${RemoteUser}@${ServerIP}" $RemoteScript

if ($LASTEXITCODE -eq 0) {
    Write-Host "Deployment Successful!" -ForegroundColor Green
    Write-Host "Dashboard available at http://${ServerIP}:7777" -ForegroundColor Green
    Remove-Item $TarFile
} else {
    Write-Error "Remote deployment failed."
}
